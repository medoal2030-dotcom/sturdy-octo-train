package com.restaurant.debts;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;

public final class Db extends SQLiteOpenHelper {
    public static final String FILE="restaurant_debts_android.db";
    public Db(Context c){super(c,FILE,null,1);}
    @Override public void onConfigure(SQLiteDatabase db){super.onConfigure(db);db.setForeignKeyConstraintsEnabled(true);}
    @Override public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE fiscal_years(id INTEGER PRIMARY KEY AUTOINCREMENT, year_label TEXT UNIQUE NOT NULL, start_date TEXT NOT NULL, end_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open')");
        d.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, full_name TEXT NOT NULL, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)");
        d.execSQL("CREATE TABLE entities(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE meal_types(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,sort_order INTEGER DEFAULT 1,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE cashiers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,active INTEGER DEFAULT 1)");
        d.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_no TEXT UNIQUE NOT NULL,name TEXT NOT NULL,phone TEXT,address TEXT,entity_id INTEGER NOT NULL,opening_balance REAL NOT NULL DEFAULT 0,active INTEGER DEFAULT 1,FOREIGN KEY(entity_id) REFERENCES entities(id))");
        d.execSQL("CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,order_no TEXT UNIQUE NOT NULL,customer_id INTEGER NOT NULL,meal_type_id INTEGER NOT NULL,cashier_id INTEGER NOT NULL,amount REAL NOT NULL,received_by TEXT,order_date TEXT NOT NULL,notes TEXT,fiscal_year_id INTEGER NOT NULL,FOREIGN KEY(customer_id) REFERENCES customers(id),FOREIGN KEY(meal_type_id) REFERENCES meal_types(id),FOREIGN KEY(cashier_id) REFERENCES cashiers(id),FOREIGN KEY(fiscal_year_id) REFERENCES fiscal_years(id))");
        d.execSQL("CREATE TABLE receipts(id INTEGER PRIMARY KEY AUTOINCREMENT,receipt_no TEXT UNIQUE NOT NULL,customer_id INTEGER NOT NULL,amount REAL NOT NULL,collector TEXT,receipt_date TEXT NOT NULL,fiscal_year_id INTEGER NOT NULL,notes TEXT,approval_status TEXT NOT NULL DEFAULT 'approved',FOREIGN KEY(customer_id) REFERENCES customers(id),FOREIGN KEY(fiscal_year_id) REFERENCES fiscal_years(id))");
        d.execSQL("CREATE TABLE discounts(id INTEGER PRIMARY KEY AUTOINCREMENT,discount_no TEXT UNIQUE NOT NULL,customer_id INTEGER NOT NULL,amount REAL NOT NULL,discounted_by TEXT NOT NULL,discount_date TEXT NOT NULL,fiscal_year_id INTEGER NOT NULL,notes TEXT,FOREIGN KEY(customer_id) REFERENCES customers(id),FOREIGN KEY(fiscal_year_id) REFERENCES fiscal_years(id))");
        d.execSQL("CREATE TABLE settings(id INTEGER PRIMARY KEY CHECK(id=1),restaurant_name TEXT NOT NULL DEFAULT 'نظام حسابات وديون المطعم')");
        d.execSQL("INSERT INTO settings(id,restaurant_name) VALUES(1,'نظام حسابات وديون المطعم')");
        seed(d,"entities",new String[]{"القيادة","السوق","المقوات","الجمارك"}); seed(d,"meal_types",new String[]{"صبوح","غداء","عشاء"}); seed(d,"cashiers",new String[]{"الكاشير الرئيسي"});
        java.util.Calendar c=java.util.Calendar.getInstance(); int y=c.get(java.util.Calendar.YEAR); ContentValues fy=new ContentValues();fy.put("year_label",String.valueOf(y));fy.put("start_date",y+"-01-01");fy.put("end_date",y+"-12-31");fy.put("status","open");d.insert("fiscal_years",null,fy);
        ContentValues u=new ContentValues();u.put("username","admin");u.put("password_hash",MainActivity.hash("admin123"));u.put("full_name","مدير النظام");u.put("role","admin");d.insert("users",null,u);
    }
    private void seed(SQLiteDatabase d,String table,String[] values){for(int i=0;i<values.length;i++){ContentValues v=new ContentValues();v.put("name",values[i]);if(table.equals("meal_types"))v.put("sort_order",i+1);d.insertWithOnConflict(table,null,v,SQLiteDatabase.CONFLICT_IGNORE);}}
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){}
    public Cursor query(String sql,String...args){return getReadableDatabase().rawQuery(sql,args);}
}
