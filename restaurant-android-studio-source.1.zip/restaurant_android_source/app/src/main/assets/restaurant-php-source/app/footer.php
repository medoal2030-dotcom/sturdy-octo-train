</main></div>
<div id="customerPicker" class="customer-picker" aria-hidden="true"><div class="customer-picker-backdrop" onclick="closeCustomerPicker()"></div><div class="customer-picker-dialog" role="dialog" aria-modal="true"><div class="customer-picker-head"><strong>اختيار العميل</strong><button type="button" class="picker-close" onclick="closeCustomerPicker()">×</button></div><div class="customer-picker-body"><input id="pickerSearch" class="picker-search" type="search" placeholder="ابحث برقم العميل أو الاسم أو الجوال..."><div class="picker-hint">F9 لفتح البحث، ثم اختر العميل.</div><div id="customerPickerList" class="customer-picker-list"><?php foreach(($customer_picker_rows??[]) as $x): ?><button type="button" class="customer-option" data-id="<?=e($x['id'])?>" data-search="<?=e($x['customer_no'].' '.$x['name'].' '.$x['phone'])?>"><span><?=e($x['customer_no'])?></span><strong><?=e($x['name'])?></strong><span><?=e($x['phone'])?></span></button><?php endforeach; ?></div></div></div></div>
<footer class="footer">نظام حسابات وديون المطعم</footer></div>
<script>
(function(){
var allowUnload=false;
// تأكيد الخروج من الحساب.
var logoutLink=document.getElementById('logoutLink');
if(logoutLink){logoutLink.addEventListener('click',function(e){if(!window.confirm('هل أنت متأكد أنك تريد الخروج من النظام؟')){e.preventDefault();return;}allowUnload=true;});}
// تحذير المتصفح عند إغلاق التبويب/النافذة؛ نص الرسالة تتحكم به إعدادات المتصفح.
window.addEventListener('beforeunload',function(e){if(allowUnload)return;e.preventDefault();e.returnValue='';return '';});
// لا تعرض تحذير الإغلاق عند التنقل المقصود داخل النظام أو إرسال النماذج.
document.addEventListener('click',function(e){var a=e.target.closest('a[href]');if(!a||a.target==='_blank'||e.defaultPrevented||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey)return;var href=a.getAttribute('href')||'';if(href.charAt(0)==='#'||/^javascript:/i.test(href)||a.hasAttribute('download'))return;allowUnload=true;});
document.addEventListener('submit',function(){allowUnload=true;},true);
// حقول التاريخ: إدخال يدوي بصيغة YYYY-MM-DD أو اختيار من التقويم.
function initManualDateFields(){document.querySelectorAll('input[type="date"]').forEach(function(original){if(original.dataset.manualDateReady)return;original.dataset.manualDateReady='1';var value=original.value||'';var name=original.name;var id=original.id;var required=original.required;var disabled=original.disabled;var min=original.min;var max=original.max;var cls=original.className;var text=document.createElement('input');text.type='text';text.name=name;text.id=id;text.value=value;text.placeholder='YYYY-MM-DD';text.inputMode='numeric';text.autocomplete='off';text.pattern='\\d{4}-\\d{2}-\\d{2}';text.title='أدخل التاريخ بصيغة YYYY-MM-DD أو اختره من التقويم';text.required=required;text.disabled=disabled;text.className=cls;text.setAttribute('aria-label',original.getAttribute('aria-label')||'التاريخ');var wrap=document.createElement('div');wrap.className='manual-date-wrap';wrap.style.cssText='display:flex;align-items:stretch;gap:5px;width:100%;position:relative';var calBtn=document.createElement('button');calBtn.type='button';calBtn.className='btn btn-light manual-date-calendar';calBtn.textContent='📅';calBtn.title='اختيار التاريخ من التقويم';calBtn.setAttribute('aria-label','اختيار التاريخ من التقويم');var picker=document.createElement('input');picker.type='date';picker.tabIndex=-1;picker.setAttribute('aria-hidden','true');picker.value=value;if(min)picker.min=min;if(max)picker.max=max;picker.style.cssText='position:absolute;left:0;top:0;width:42px;height:100%;opacity:0;cursor:pointer;margin:0';text.style.flex='1';text.style.minWidth='0';original.parentNode.insertBefore(wrap,original);wrap.appendChild(text);wrap.appendChild(calBtn);wrap.appendChild(picker);original.remove();function valid(v){return /^\d{4}-\d{2}-\d{2}$/.test(v)}text.addEventListener('input',function(){if(valid(text.value)){picker.value=text.value;}else{picker.value='';}});text.addEventListener('blur',function(){if(text.value.trim()&&!valid(text.value)){text.setCustomValidity('أدخل التاريخ بصيغة YYYY-MM-DD أو اختره من التقويم.');}else{text.setCustomValidity('');}});text.addEventListener('input',function(){text.setCustomValidity('');});picker.addEventListener('change',function(){text.value=picker.value;text.setCustomValidity('');text.dispatchEvent(new Event('change',{bubbles:true}));});calBtn.addEventListener('click',function(){if(disabled)return;try{if(picker.showPicker)picker.showPicker();else picker.click();}catch(e){picker.click();}});});}document.addEventListener('DOMContentLoaded',initManualDateFields);
// التنقل بين خانات الإدخال بزر Enter في جميع صفحات النظام.
// إذا كانت الخانة الحالية مطلوبة ولم تُملأ أو كانت غير صحيحة، يبقى التركيز فيها ولا ينتقل.
document.addEventListener('keydown',function(e){
 if(e.key!=='Enter'||e.shiftKey||e.ctrlKey||e.altKey||e.metaKey)return;
 var el=e.target;
 if(!el||!el.matches||!el.matches('input,select,textarea'))return;
 if(el.tagName==='TEXTAREA'||el.readOnly||el.disabled||['hidden','submit','button','reset','image','checkbox','radio','file'].indexOf((el.type||'').toLowerCase())!==-1)return;
 var form=el.form;
 // حقول البحث تستخدم Enter لتنفيذ البحث لا للتنقل بين حقول النموذج.
 if(el.type==='search'||(form&&form.classList.contains('search-form')))return;
 if(el.required){
   if(typeof el.checkValidity==='function'&&!el.checkValidity()){
     e.preventDefault(); if(typeof el.reportValidity==='function')el.reportValidity(); else el.focus(); return;
   }
   if(!String(el.value||'').trim()){
     e.preventDefault(); if(typeof el.reportValidity==='function')el.reportValidity(); else el.focus(); return;
   }
 }
 if(form){
   var fields=Array.prototype.slice.call(form.querySelectorAll('input,select,textarea')).filter(function(x){
     var t=(x.type||'').toLowerCase();
     return !x.disabled&&!x.readOnly&&x.tabIndex!==-1&&x.type!=='hidden'&&['submit','button','reset','image','checkbox','radio','file'].indexOf(t)===-1&&x.getClientRects().length>0;
   });
   var i=fields.indexOf(el);
   if(i>=0&&i<fields.length-1){e.preventDefault();fields[i+1].focus();if(fields[i+1].select&&['text','number','search','tel','url','email'].indexOf((fields[i+1].type||'').toLowerCase())!==-1){try{fields[i+1].select()}catch(ignore){}}}
 }
},true);
var picker,target,search,list;function init(){picker=document.getElementById('customerPicker');search=document.getElementById('pickerSearch');list=document.getElementById('customerPickerList');if(!picker)return;list.addEventListener('click',function(e){var b=e.target.closest('.customer-option');if(!b||!target)return;target.value=b.dataset.id;target.dispatchEvent(new Event('change',{bubbles:true}));closeCustomerPicker();});search.addEventListener('input',filter)}function filter(){var q=(search.value||'').trim().toLowerCase(),n=0;list.querySelectorAll('.customer-option').forEach(function(b){var ok=!q||(b.dataset.search||'').toLowerCase().indexOf(q)>-1;b.style.display=ok?'grid':'none';if(ok)n++});var e=list.querySelector('.picker-empty');if(!n&&!e){e=document.createElement('div');e.className='picker-empty';e.textContent='لا توجد نتائج مطابقة.';list.appendChild(e)}if(n&&e)e.remove()}window.openCustomerPicker=function(s){if(!picker)return;target=s;picker.classList.add('open');picker.setAttribute('aria-hidden','false');search.value='';filter();setTimeout(function(){search.focus({preventScroll:true});if(search.setSelectionRange)search.setSelectionRange(0,0)},0)};window.closeCustomerPicker=function(){if(!picker)return;picker.classList.remove('open');picker.setAttribute('aria-hidden','true');target=null};document.addEventListener('keydown',function(e){if(e.key==='F9'){var s=document.activeElement&&document.activeElement.name==='customer_id'?document.activeElement:document.querySelector('select[name="customer_id"]');if(s){e.preventDefault();openCustomerPicker(s)}}if(e.key==='Escape'&&picker&&picker.classList.contains('open'))closeCustomerPicker()});document.addEventListener('DOMContentLoaded',init);document.querySelectorAll('.nav-drop-btn').forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();var p=this.parentElement;p.classList.toggle('open');document.querySelectorAll('.nav-dropdown').forEach(function(x){if(x!==p)x.classList.remove('open')})})});document.addEventListener('click',function(e){if(!e.target.closest('.nav-dropdown'))document.querySelectorAll('.nav-dropdown').forEach(function(x){x.classList.remove('open')})})})();
</script></body></html>
