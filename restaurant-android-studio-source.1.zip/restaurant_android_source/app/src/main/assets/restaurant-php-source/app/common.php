<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$config = require __DIR__.'/config.php';
$dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['db']};charset={$config['charset']}";
try {
  $pdo = new PDO($dsn,$config['user'],$config['pass'],[
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES=>false,
  ]);
} catch (Throwable $e) { http_response_code(500); die('تعذر الاتصال بقاعدة البيانات: '.htmlspecialchars($e->getMessage(),ENT_QUOTES,'UTF-8')); }
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function redirect($url){header('Location: '.$url);exit;}
function csrf(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(24)); return $_SESSION['csrf']; }
function check_csrf(){ if(!hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')){http_response_code(419);die('انتهت صلاحية النموذج، أعد المحاولة.');} }
function flash($type,$msg){$_SESSION['flash']=[$type,$msg];}
function get_flash(){ $f=$_SESSION['flash']??null; unset($_SESSION['flash']); return $f; }
function auth(){ if(empty($_SESSION['user'])) redirect('login.php'); $role=$_SESSION['user']['role']??''; $page=basename($_SERVER['SCRIPT_NAME']??''); if($role==='collector' && !in_array($page,['receipt.php','collector_report.php','receipt_print.php','logout.php'],true)){ flash('error','صلاحية المحصل تقتصر على إنشاء سندات القبض المعلقة بانتظار اعتماد المدير.'); redirect('receipt.php'); } }
function admin(){ if(($_SESSION['user']['role']??'')!=='admin'){http_response_code(403);die('ليس لديك صلاحية لهذا الإجراء.');} }
function current_year($pdo){$r=$pdo->query("SELECT * FROM fiscal_years WHERE status='open' ORDER BY id DESC LIMIT 1")->fetch(); if(!$r){$y=date('Y');$s=$pdo->prepare("INSERT INTO fiscal_years(year_label,start_date,end_date,status) VALUES(?,?,?,'open')");$s->execute([$y,"$y-01-01","$y-12-31"]);$r=$pdo->query("SELECT * FROM fiscal_years WHERE id=".$pdo->lastInsertId())->fetch();} $s=$pdo->prepare("INSERT IGNORE INTO customer_year_balances(fiscal_year_id,customer_id,opening_balance) SELECT ?,id,opening_balance FROM customers WHERE active=1");$s->execute([$r['id']]); return $r;}
function money($v){return number_format((float)$v,2,'.',',');}

/* إعدادات عامة للنظام - تنشأ تلقائياً عند تحديث النسخة */
try {
  $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
    id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    restaurant_name_ar VARCHAR(180) NOT NULL DEFAULT 'نظام حسابات وديون المطعم',
    home_page_name_ar VARCHAR(180) NULL,
    restaurant_name_en VARCHAR(180) NULL,
    address_ar VARCHAR(255) NULL,
    address_en VARCHAR(255) NULL,
    phones_ar VARCHAR(255) NULL,
    phones_en VARCHAR(255) NULL,
    logo VARCHAR(255) NULL,
    accounts_mark_path VARCHAR(255) NULL,
    branch_no VARCHAR(50) NOT NULL DEFAULT '1',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $pdo->exec("INSERT IGNORE INTO system_settings(id,restaurant_name_ar) VALUES(1,'نظام حسابات وديون المطعم')");
  $pdo->exec("CREATE TABLE IF NOT EXISTS user_notifications (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, receipt_id BIGINT UNSIGNED NULL, message VARCHAR(255) NOT NULL, is_read TINYINT(1) NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX idx_user_notifications(user_id,is_read,id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  try { $pdo->exec("ALTER TABLE users ADD COLUMN permissions TEXT NULL AFTER active"); } catch(Throwable $ignore) {}
  try { $pdo->exec("ALTER TABLE users MODIFY role ENUM('admin','accountant','cashier','collector','viewer') NOT NULL DEFAULT 'cashier'"); } catch(Throwable $ignore) {}
  try { $pdo->exec("ALTER TABLE receipts ADD COLUMN approval_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved' AFTER notes"); } catch(Throwable $ignore) {}
  try { $pdo->exec("ALTER TABLE receipts ADD COLUMN approved_by INT UNSIGNED NULL AFTER approval_status"); } catch(Throwable $ignore) {}
  try { $pdo->exec("ALTER TABLE receipts ADD COLUMN approved_at DATETIME NULL AFTER approved_by"); } catch(Throwable $ignore) {}
  try { $pdo->exec("ALTER TABLE receipts ADD CONSTRAINT fk_receipts_approved_by FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL"); } catch(Throwable $ignore) {}
  try { $pdo->exec("ALTER TABLE system_settings ADD COLUMN branch_no VARCHAR(50) NOT NULL DEFAULT '1' AFTER logo"); } catch(Throwable $ignore) {}
  try { $pdo->exec("ALTER TABLE system_settings ADD COLUMN home_page_name_ar VARCHAR(180) NULL AFTER restaurant_name_ar"); } catch(Throwable $ignore) {}
  try { $pdo->exec("ALTER TABLE system_settings ADD COLUMN accounts_mark_path VARCHAR(255) NULL AFTER logo"); } catch(Throwable $ignore) {}
} catch(Throwable $ignore) {}
function setting($key,$default=''){
  global $pdo;
  static $settings=null;
  if($settings===null){$settings=$pdo->query("SELECT * FROM system_settings WHERE id=1")->fetch() ?: [];}
  return array_key_exists($key,$settings) ? ($settings[$key]??$default) : $default;
}
function user_permissions(){
  $u=$_SESSION['user']??[]; if(($u['role']??'')==='admin') return ['*'];
  $p=json_decode($u['permissions']??'',true); return is_array($p)?$p:[];
}
function can_do($permission){$p=user_permissions(); return in_array('*',$p,true)||in_array($permission,$p,true);}
function arabic_amount_words($amount){
  $amount=round((float)$amount,2); $negative=$amount<0; $amount=abs($amount);
  $whole=(int)floor($amount); $frac=(int)round(($amount-$whole)*100);
  $ones=['','واحد','اثنان','ثلاثة','أربعة','خمسة','ستة','سبعة','ثمانية','تسعة','عشرة','أحد عشر','اثنا عشر','ثلاثة عشر','أربعة عشر','خمسة عشر','ستة عشر','سبعة عشر','ثمانية عشر','تسعة عشر'];
  $tens=['','','عشرون','ثلاثون','أربعون','خمسون','ستون','سبعون','ثمانون','تسعون'];
  $groups=[['',''],['ألف','آلاف'],['مليون','ملايين'],['مليار','مليارات']];
  $under100=function($n)use(&$ones,&$tens){if($n<20)return $ones[$n];$u=$n%10;$t=intdiv($n,10);return $u?($ones[$u].' و'.$tens[$t]):$tens[$t];};
  $under1000=function($n)use(&$under100,&$ones){if($n<100)return $under100($n);$h=intdiv($n,100);$r=$n%100;$hw=['','مائة','مائتان','ثلاثمائة','أربعمائة','خمسمائة','ستمائة','سبعمائة','ثمانمائة','تسعمائة'][$h];return $r?$hw.' و'.$under100($r):$hw;};
  if($whole===0)$words='صفر'; else {$parts=[];$i=0;while($whole>0&&$i<count($groups)){$n=$whole%1000;if($n){$g=$groups[$i];if($i===0)$parts[]=$under1000($n);elseif($n===1)$parts[]=$g[0];elseif($n===2)$parts[]='اثنان '.$g[0];elseif($n>=3&&$n<=10)$parts[]=$under1000($n).' '.$g[1];else $parts[]=$under1000($n).' '.$g[0];}$whole=intdiv($whole,1000);$i++;}$words=implode(' و',array_reverse($parts));}
  if($frac>0)$words.=' و'.$frac.' من مائة';
  return ($negative?'سالب ':'').$words;
}
