<?php
require_once __DIR__.'/common.php';

function report_prev_balance(PDO $pdo, array $yr, int $customer, string $beforeDate): float {
    $bal = 0.0;
    $s = $pdo->prepare("SELECT COALESCE(opening_balance,0) FROM customer_year_balances WHERE fiscal_year_id=? AND customer_id=?");
    $s->execute([$yr['id'], $customer]);
    $bal += (float)$s->fetchColumn();

    $s = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM orders WHERE customer_id=? AND fiscal_year_id=? AND order_date>=? AND order_date<?");
    $s->execute([$customer, $yr['id'], $yr['start_date'], $beforeDate]);
    $bal += (float)$s->fetchColumn();

    $s = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM receipts WHERE approval_status='approved' AND customer_id=? AND fiscal_year_id=? AND receipt_date>=? AND receipt_date<?");
    $s->execute([$customer, $yr['id'], $yr['start_date'], $beforeDate]);
    $bal -= (float)$s->fetchColumn();

    $s = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM discounts WHERE customer_id=? AND fiscal_year_id=? AND discount_date>=? AND discount_date<?");
    $s->execute([$customer, $yr['id'], $yr['start_date'], $beforeDate]);
    $bal -= (float)$s->fetchColumn();
    return $bal;
}

function report_header(string $title, string $from, string $to, string $extra=''): void {
    $logo = setting('logo');
    echo '<div class="report-header">';
    echo '<div class="report-brand report-brand-ar"><h2>'.e(setting('restaurant_name_ar')).'</h2>';
    echo '<div>'.e(setting('address_ar')).'</div><div>'.e(setting('phones_ar')).'</div></div>';
    echo '<div class="report-logo">';
    if ($logo && is_file(__DIR__.'/../public/'.$logo)) echo '<img src="'.e($logo).'" alt="الشعار">';
    echo '</div><div class="report-brand report-brand-en" dir="ltr"><h2>'.e(setting('restaurant_name_en')).'</h2>';
    echo '<div>'.e(setting('address_en')).'</div><div>'.e(setting('phones_en')).'</div></div></div>';
    echo '<h3 class="report-main-title">'.e($title).'</h3>';
    $period = $from === $to ? 'التاريخ: '.e($from) : 'الفترة: '.e($from).' إلى '.e($to);
    echo '<div class="print-only report-meta">'.$period.($extra!==''?' — '.e($extra):'').'</div>';
}

function report_footer(): void {
    $mark = setting('accounts_mark_path');
    // Signature/stamp belongs to the end of report content (last page only).
    echo '<div class="report-signature-end"><div class="report-signature-label"><strong>إدارة الحسابات</strong><span>التوقيع / الختم</span></div>';
    if ($mark && is_file(__DIR__.'/../public/'.$mark)) echo '<img class="report-account-mark" src="'.e($mark).'" alt="توقيع أو ختم إدارة الحسابات">';
    else echo '<span class="report-signature-placeholder">مساحة التوقيع أو الختم</span>';
    echo '</div>';
    // Fixed footer is repeated by print engines on each printed page.
    echo '<div class="report-print-footer"><div class="report-footer-meta"><span class="report-current-user">'.e($_SESSION['user']['full_name']??'').'</span></div></div>';
}

function report_dates(array $yr): array {
    $from = $_GET['from'] ?? date('Y-m-d');
    $to = $_GET['to'] ?? date('Y-m-d');
    if ($from < $yr['start_date']) $from = $yr['start_date'];
    if ($to > $yr['end_date']) $to = $yr['end_date'];
    if ($from > $to) [$from,$to] = [$to,$from];
    return [$from,$to];
}
