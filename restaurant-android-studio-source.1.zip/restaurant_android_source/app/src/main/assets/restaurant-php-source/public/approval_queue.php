<?php
$title='اعتماد سندات القبض'; require __DIR__.'/../app/header.php'; admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
  check_csrf(); $id=(int)($_POST['id']??0); $action=$_POST['action']??'';
  $s=$pdo->prepare("SELECT id,receipt_no FROM receipts WHERE id=? AND approval_status='pending'"); $s->execute([$id]); $row=$s->fetch();
  if(!$row){flash('error','السند غير موجود أو تمت معالجته مسبقًا.');redirect('approval_queue.php');}
  if($action==='approve'){
    $pdo->prepare("UPDATE receipts SET approval_status='approved',approved_by=?,approved_at=NOW() WHERE id=? AND approval_status='pending'")->execute([$_SESSION['user']['id'],$id]);
    $ns=$pdo->prepare("SELECT created_by FROM receipts WHERE id=?");$ns->execute([$id]);$owner=(int)$ns->fetchColumn();if($owner>0){$n=$pdo->prepare("INSERT INTO user_notifications(user_id,receipt_id,message) VALUES(?,?,?)");$n->execute([$owner,$id,'تم اعتماد التحصيل للسند '.$row['receipt_no'].'.']);}
    flash('success','تم اعتماد السند '.$row['receipt_no'].' وإدخاله في حساب العميل.');
  } elseif($action==='reject') {
    $pdo->prepare("UPDATE receipts SET approval_status='rejected',approved_by=?,approved_at=NOW() WHERE id=? AND approval_status='pending'")->execute([$_SESSION['user']['id'],$id]);
    flash('success','تم رفض السند '.$row['receipt_no'].' ولم يؤثر في حساب العميل.');
  }
  redirect('approval_queue.php');
}
$rows=$pdo->query("SELECT r.*,c.customer_no,c.name customer_name,c.phone,u.full_name created_by_name FROM receipts r JOIN customers c ON c.id=r.customer_id LEFT JOIN users u ON u.id=r.created_by WHERE r.approval_status='pending' ORDER BY r.created_at ASC,r.id ASC")->fetchAll();
?>
<div class="page-title">اعتماد سندات القبض</div>
<div class="panel"><div class="panel-head">السندات المرسلة من المحصلين</div><div class="panel-body">
<p class="muted">السند المعلّق لا يخصم من مديونية العميل ولا يظهر كتحصيل معتمد حتى يوافق المدير عليه.</p>
<?php if(!$rows):?><div class="empty-state">لا توجد سندات بانتظار الاعتماد.</div><?php else:?><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:14px">
<?php foreach($rows as $r):?><article class="panel" style="margin:0;border:1px solid #d7e1e6;border-radius:12px;overflow:hidden"><div class="panel-head" style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap"><strong>سند قبض</strong><b dir="ltr"><?=e($r['receipt_no'])?></b></div><div class="panel-body"><div class="customer-detail-grid"><div><small>العميل</small><b><?=e($r['customer_name'])?></b></div><div><small>رقم العميل</small><b><?=e($r['customer_no'])?></b></div><div><small>المبلغ</small><b style="font-size:20px;color:#087f82"><?=money($r['amount'])?></b></div><div><small>المحصل</small><b><?=e($r['collector']?:$r['created_by_name']?:'—')?></b></div><div><small>تاريخ السند</small><b><?=e($r['receipt_date'])?></b></div><div><small>تاريخ الإرسال</small><b><?=e($r['created_at'])?></b></div><?php if($r['notes']):?><div style="grid-column:1/-1"><small>ملاحظات</small><b><?=e($r['notes'])?></b></div><?php endif;?></div><div class="actions" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px"><form method="post" onsubmit="return confirm('تأكيد اعتماد هذا السند؟ سيخصم المبلغ من مديونية العميل.');"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="id" value="<?=$r['id']?>"><input type="hidden" name="action" value="approve"><button class="btn btn-primary">اعتماد السند</button></form><form method="post" onsubmit="return confirm('رفض هذا السند؟ لن يؤثر في حساب العميل.');"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="id" value="<?=$r['id']?>"><input type="hidden" name="action" value="reject"><button class="btn btn-danger">رفض</button></form></div></div></article><?php endforeach;?></div><?php endif;?>
</div></div><?php require __DIR__.'/../app/footer.php';?>
