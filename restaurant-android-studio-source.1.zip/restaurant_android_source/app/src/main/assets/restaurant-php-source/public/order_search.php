<?php
$title='بحث الطلبات'; require __DIR__.'/../app/header.php';
$orderNo=trim($_GET['order_no']??''); $customerQ=trim($_GET['customer_q']??'');
$results=[]; $mode='';
if($orderNo!==''){
  $mode='order';
  $s=$pdo->prepare("SELECT o.id,o.order_no,o.order_date,o.amount,o.received_by,c.name customer_name,m.name meal_name,ca.name cashier_name FROM orders o JOIN customers c ON c.id=o.customer_id JOIN meal_types m ON m.id=o.meal_type_id LEFT JOIN cashiers ca ON ca.id=o.cashier_id WHERE o.order_no LIKE ? ORDER BY o.id DESC LIMIT 100");
  $s->execute(['%'.$orderNo.'%']); $results=$s->fetchAll();
}elseif($customerQ!==''){
  $mode='customer';
  $s=$pdo->prepare("SELECT o.id,o.order_no,o.order_date,o.amount,o.received_by,c.name customer_name,m.name meal_name,ca.name cashier_name FROM orders o JOIN customers c ON c.id=o.customer_id JOIN meal_types m ON m.id=o.meal_type_id LEFT JOIN cashiers ca ON ca.id=o.cashier_id WHERE c.name LIKE ? ORDER BY o.order_date DESC,o.id DESC LIMIT 200");
  $s->execute(['%'.$customerQ.'%']); $results=$s->fetchAll();
}
?>
<div class="page-title">بحث عن الطلبات</div>
<div class="panel"><div class="panel-head">بحث مستقل عن الطلبات</div><div class="panel-body"><div class="search-grid">
<form method="get" class="search-card"><div class="search-title">بحث برقم الطلب</div><input name="order_no" value="<?=e($orderNo)?>" placeholder="اكتب رقم الطلب"><button class="btn btn-primary">بحث</button></form>
<form method="get" class="search-card"><div class="search-title">بحث باسم العميل</div><input name="customer_q" value="<?=e($customerQ)?>" placeholder="اكتب اسم العميل"><button class="btn btn-secondary">عرض الطلبات</button></form>
</div></div></div>
<?php if($mode): ?><div class="panel"><div class="panel-head">نتائج البحث</div><div class="panel-body"><div class="table-wrap"><table class="table data-grid"><thead><tr><th>رقم الطلب</th><th>اسم العميل</th><th>الوجبة</th><th>الكاشير</th><th>المبلغ</th><th>مستلم الطلب</th><th>التاريخ</th><th>إجراء</th></tr></thead><tbody><?php if(!$results): ?><tr><td colspan="8" class="empty-cell">لا توجد نتائج مطابقة.</td></tr><?php else: foreach($results as $r): ?><tr><td><a class="order-link" href="order.php?edit=<?=$r['id']?>"><?=e($r['order_no'])?></a></td><td><?=e($r['customer_name'])?></td><td><?=e($r['meal_name'])?></td><td><?=e($r['cashier_name'])?></td><td><?=money($r['amount'])?></td><td><?=e($r['received_by'])?></td><td><?=e($r['order_date'])?></td><td><a class="btn btn-light" href="order.php?edit=<?=$r['id']?>">فتح وتعديل</a></td></tr><?php endforeach; endif; ?></tbody></table></div></div></div><?php endif; ?>
<?php require __DIR__.'/../app/footer.php'; ?>
