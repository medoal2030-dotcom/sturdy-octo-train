<?php
require_once __DIR__.'/../app/common.php';
auth(); admin();

function split_backup_sql($sql) {
  $statements=[]; $buffer=''; $quote=null; $escaped=false; $lineComment=false; $blockComment=false; $len=strlen($sql);
  for($i=0;$i<$len;$i++) {
    $ch=$sql[$i]; $next=$i+1<$len?$sql[$i+1]:'';
    if($lineComment) { if($ch==="\n") { $lineComment=false; $buffer.="\n"; } continue; }
    if($blockComment) { if($ch==='*' && $next==='/') { $blockComment=false; $i++; } continue; }
    if($quote!==null) {
      $buffer.=$ch;
      if($escaped) { $escaped=false; continue; }
      if($ch==='\\' && $quote!== '`') { $escaped=true; continue; }
      if($ch===$quote) { if($next===$quote) { $buffer.=$next; $i++; } else { $quote=null; } }
      continue;
    }
    if(($ch==='-' && $next==='-' && ($i+2 >= $len || ctype_space($sql[$i+2]))) || $ch==='#') { $lineComment=true; if($ch==='-')$i++; continue; }
    if($ch==='/' && $next==='*') { $blockComment=true; $i++; continue; }
    if($ch==="'" || $ch==='"' || $ch==='`') { $quote=$ch; $buffer.=$ch; continue; }
    if($ch===';') { $statement=trim($buffer); if($statement!=='')$statements[]=$statement; $buffer=''; continue; }
    $buffer.=$ch;
  }
  $last=trim($buffer); if($last!=='')$statements[]=$last;
  if($quote!==null || $blockComment) throw new RuntimeException('ملف النسخة الاحتياطية غير مكتمل أو يحتوي على نص SQL غير صحيح.');
  return $statements;
}

if($_SERVER['REQUEST_METHOD']==='POST') {
  check_csrf();
  if(($_POST['confirm_restore']??'')!=='yes') { flash('error','يجب تأكيد الاستعادة قبل المتابعة.'); redirect('restore_backup.php'); }
  if(!isset($_FILES['backup_file']) || $_FILES['backup_file']['error']!==UPLOAD_ERR_OK) {
    flash('error','تعذر رفع الملف. تحقق من اختيار ملف SQL ومن حد حجم الرفع في إعدادات الخادم.'); redirect('restore_backup.php');
  }
  $file=$_FILES['backup_file'];
  if((int)$file['size']<1 || (int)$file['size']>50*1024*1024) { flash('error','حجم الملف غير صالح. الحد الأقصى 50 ميجابايت.'); redirect('restore_backup.php'); }
  if(strtolower(pathinfo($file['name'],PATHINFO_EXTENSION))!=='sql' || !is_uploaded_file($file['tmp_name'])) { flash('error','يرجى اختيار ملف نسخة احتياطية بامتداد .sql.'); redirect('restore_backup.php'); }
  $sql=file_get_contents($file['tmp_name']);
  if($sql===false || stripos($sql,'Restaurant Debts backup')===false || stripos($sql,'SET FOREIGN_KEY_CHECKS=0')===false) { flash('error','الملف لا يبدو نسخة احتياطية صادرة من نظام حسابات وديون المطعم.'); redirect('restore_backup.php'); }
  try {
    $statements=split_backup_sql($sql);
    if(!$statements) throw new RuntimeException('ملف النسخة الاحتياطية فارغ.');
    foreach($statements as $statement) {
      if(!preg_match('/^(SET\s+NAMES\s+utf8mb4|SET\s+FOREIGN_KEY_CHECKS\s*=\s*[01]|DROP\s+TABLE\s+IF\s+EXISTS\s+`[A-Za-z0-9_]+`|CREATE\s+TABLE\s+`?[A-Za-z0-9_]+`?|INSERT\s+INTO\s+`[A-Za-z0-9_]+`\s*\()/i',$statement)) {
        throw new RuntimeException('الملف يحتوي على أمر غير مسموح به في النسخة الاحتياطية.');
      }
    }
    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
    try { foreach($statements as $statement) $pdo->exec($statement); }
    finally { $pdo->exec('SET FOREIGN_KEY_CHECKS=1'); }
    flash('success','تمت استعادة النسخة الاحتياطية بنجاح. أعد تحميل النظام للتحقق من البيانات المستعادة.');
  } catch(Throwable $ex) {
    try { $pdo->exec('SET FOREIGN_KEY_CHECKS=1'); } catch(Throwable $ignore) {}
    flash('error','تعذرت الاستعادة بالكامل: '. $ex->getMessage().' قد تكون بعض الجداول تغيرت؛ إذا حدث ذلك، أعد الاستعادة باستخدام ملف نسخة احتياطية سليم.');
  }
  redirect('restore_backup.php');
}

$title='استعادة نسخة احتياطية'; require __DIR__.'/../app/header.php';
?>
<div class="page-title">استعادة نسخة احتياطية</div>
<div class="panel"><div class="panel-head">استعادة بيانات النظام من ملف SQL</div><div class="panel-body">
  <div class="alert alert-info">اختر ملف النسخة الاحتياطية بامتداد <strong>.sql</strong> الذي تم إنشاؤه من خيار «نسخة احتياطية» في النظام.</div>
  <div class="alert alert-danger"><strong>تنبيه مهم:</strong> الاستعادة تستبدل البيانات والجداول الحالية بالبيانات الموجودة في النسخة الاحتياطية، وقد تفقد أي تغييرات أُجريت بعد تاريخ النسخة. أنشئ نسخة احتياطية حديثة قبل المتابعة.</div>
  <form method="post" enctype="multipart/form-data" onsubmit="return confirm('تحذير نهائي: سيتم استبدال بيانات النظام الحالية بالنسخة المختارة. هل أنشأت نسخة احتياطية حديثة وتريد الاستمرار؟');">
    <input type="hidden" name="csrf" value="<?=e(csrf())?>">
    <div class="form-row"><label for="backup_file">ملف النسخة الاحتياطية (.sql)</label><input id="backup_file" type="file" name="backup_file" accept=".sql,application/sql,text/plain" required><small>الحد الأقصى لحجم الملف: 50 ميجابايت، وقد يحد إعداد الخادم من حجم الرفع.</small></div>
    <div class="form-row" style="margin-top:12px"><label><input type="checkbox" name="confirm_restore" value="yes" required> أؤكد أنني أفهم أن الاستعادة ستستبدل البيانات الحالية.</label></div>
    <div class="actions"><button class="btn btn-danger" type="submit">استعادة النسخة الاحتياطية</button><a class="btn btn-light" href="backup.php">العودة إلى النسخ الاحتياطي</a></div>
  </form>
</div></div>
<?php require __DIR__.'/../app/footer.php'; ?>
