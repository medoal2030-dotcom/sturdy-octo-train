<?php
$title='تقرير التحصيل اليومي'; require __DIR__.'/../app/header.php'; require __DIR__.'/../app/report_common.php';
$entities=$pdo->query("SELECT id,name FROM entities WHERE active=1 ORDER BY name")->fetchAll(); $viewData=(($_GET['view']??'')==='1');
$yr=current_year($pdo); $date=$_GET['date']??date('Y-m-d'); if($date<$yr['start_date'])$date=$yr['start_date']; if($date>$yr['end_date'])$date=$yr['end_date']; $from=$date; $to=$date; $entity=(int)($_GET['entity_id']??0); $entityName='';
foreach($entities as $x){if((int)$x['id']===$entity)$entityName=$x['name'];}
$where=['c.active=1']; $p=[];
if($entity){$where[]='c.entity_id=?';$p[]=$entity;}
/* الرصيد السابق هو رصيد العميل التراكمي قبل بداية الفترة، وفق نفس حساب كشف الحساب. */
$sql="SELECT c.id,c.customer_no,c.name customer_name,e.name entity_name,
 COALESCE(cyb.opening_balance,c.opening_balance,0)
 + COALESCE((SELECT SUM(o.amount) FROM orders o WHERE o.customer_id=c.id AND o.fiscal_year_id=? AND o.order_date>=? AND o.order_date<?),0)
 - COALESCE((SELECT SUM(r.amount) FROM receipts r WHERE r.approval_status='approved' AND r.customer_id=c.id AND r.fiscal_year_id=? AND r.receipt_date>=? AND r.receipt_date<?),0)
 - COALESCE((SELECT SUM(d.amount) FROM discounts d WHERE d.customer_id=c.id AND d.fiscal_year_id=? AND d.discount_date>=? AND d.discount_date<?),0) previous_balance,
 COALESCE((SELECT SUM(o.amount) FROM orders o JOIN meal_types m ON m.id=o.meal_type_id WHERE o.customer_id=c.id AND o.fiscal_year_id=? AND o.order_date BETWEEN ? AND ? AND m.name='عشاء'),0) dinner,
 COALESCE((SELECT SUM(o.amount) FROM orders o JOIN meal_types m ON m.id=o.meal_type_id WHERE o.customer_id=c.id AND o.fiscal_year_id=? AND o.order_date BETWEEN ? AND ? AND m.name='صبوح'),0) breakfast,
 COALESCE((SELECT SUM(o.amount) FROM orders o JOIN meal_types m ON m.id=o.meal_type_id WHERE o.customer_id=c.id AND o.fiscal_year_id=? AND o.order_date BETWEEN ? AND ? AND m.name='غداء'),0) lunch,
 COALESCE((SELECT SUM(o.amount) FROM orders o WHERE o.customer_id=c.id AND o.fiscal_year_id=? AND o.order_date BETWEEN ? AND ?),0) period_total,
 COALESCE((SELECT SUM(r.amount) FROM receipts r WHERE r.approval_status='approved' AND r.customer_id=c.id AND r.fiscal_year_id=? AND r.receipt_date BETWEEN ? AND ?),0) period_receipts,
 COALESCE((SELECT SUM(d.amount) FROM discounts d WHERE d.customer_id=c.id AND d.fiscal_year_id=? AND d.discount_date BETWEEN ? AND ?),0) period_discounts
 FROM customers c JOIN entities e ON e.id=c.entity_id
 LEFT JOIN customer_year_balances cyb ON cyb.customer_id=c.id AND cyb.fiscal_year_id=?
 WHERE ".implode(' AND ',$where)."
 ORDER BY c.name,c.customer_no";
$p=array_merge([
 $yr['id'],$yr['start_date'],$from,
 $yr['id'],$yr['start_date'],$from,
 $yr['id'],$yr['start_date'],$from,
 $yr['id'],$from,$to,
 $yr['id'],$from,$to,
 $yr['id'],$from,$to,
 $yr['id'],$from,$to,
 $yr['id'],$from,$to,
 $yr['id'],$from,$to,
 $yr['id']
],$p);
$s=$pdo->prepare($sql);$s->execute($p);$rows=$s->fetchAll();
// التقرير الحالي يعرض فقط العملاء الذين لديهم حركة/طلبات خلال الفترة المحددة.
// العملاء الذين لا توجد لهم حركة في الفترة ولكن ما زال عليهم رصيد غير مسدد
// يتم عرضهم في صندوق الملاحظات فقط.
$rows=array_values(array_filter($rows,function($r){
  return abs((float)$r['period_total']) > 0.00001;
}));

$noteWhere=[];
$noteParams=[];
if($entity){$noteWhere[]='c.entity_id=?';$noteParams[]=$entity;}
// صندوق الملاحظات يحسب المديونية المتبقية من كامل سجل العميل حتى نهاية الفترة،
// بغض النظر عن السنة المالية أو حالة تفعيل العميل؛ ثم يستبعد من ظهر في الجدول الحالي.
$currentIds=array_values(array_unique(array_map('intval',array_column($rows,'id'))));
if($currentIds){
  $noteWhere[]='c.id NOT IN ('.implode(',',array_fill(0,count($currentIds),'?')).')';
}
$noteSql="SELECT c.id,c.customer_no,c.name customer_name,e.name entity_name,
 (SELECT MAX(rp.receipt_date) FROM receipts rp WHERE rp.customer_id=c.id AND rp.approval_status='approved' AND rp.receipt_date<=?) last_payment_date,
 COALESCE(c.opening_balance,0)
 + COALESCE((SELECT SUM(o.amount) FROM orders o WHERE o.customer_id=c.id AND o.order_date<=?),0)
 - COALESCE((SELECT SUM(r.amount) FROM receipts r WHERE r.approval_status='approved' AND r.customer_id=c.id AND r.receipt_date<=?),0)
 - COALESCE((SELECT SUM(d.amount) FROM discounts d WHERE d.customer_id=c.id AND d.discount_date<=?),0) balance
 FROM customers c
 JOIN entities e ON e.id=c.entity_id";
if($noteWhere){$noteSql.=' WHERE '.implode(' AND ',$noteWhere);}
$noteSql.=" HAVING balance > 0.009 AND (last_payment_date IS NULL OR last_payment_date BETWEEN DATE_SUB(?, INTERVAL 3 DAY) AND DATE_SUB(?, INTERVAL 1 DAY)) ORDER BY c.name,c.customer_no";
$noteP=array_merge([$to,$to,$to,$to],$noteParams,$currentIds,[$to,$to]);
$ns=$pdo->prepare($noteSql);$ns->execute($noteP);$previousDebtors=$ns->fetchAll();
$reportHasData = $viewData && (!empty($rows) || !empty($previousDebtors));
// لا يتم جمع أرصدة الترحيل بين السنوات معًا؛ الحساب يعتمد على الرصيد الافتتاحي الأصلي
// والحركات المسجلة فعليًا، لتجنب فقد المديونيات عند عدم ترحيل سنة سابقة.
?>
<div class="page-title">تقرير التحصيل اليومي</div>
<div class="panel no-print"><div class="panel-head">خيارات التقرير</div><div class="panel-body"><form method="get"><input type="hidden" name="view" value="1"><div class="grid"><div class="col-4 form-row"><label>تاريخ التقرير</label><input type="date" name="date" value="<?=e($date)?>" required></div><div class="col-4 form-row"><label>الجهة</label><select name="entity_id"><option value="0">كل الجهات</option><?php foreach($entities as $x):?><option value="<?=$x['id']?>" <?=$entity===$x['id']?'selected':''?>><?=e($x['name'])?></option><?php endforeach;?></select></div></div><div class="actions"><button class="btn btn-primary btn-view-data">عرض البيانات</button><button type="button" class="btn btn-secondary" onclick="window.print()" <?=!$reportHasData?'disabled title="لا توجد بيانات للطباعة"':''?>>طباعة A4</button><a class="btn btn-light" href="daily_collection.php">إعادة ضبط</a></div></form></div></div>
<?php if(!$viewData): ?><div class="empty-state">حدد التاريخ والجهة ثم اضغط «عرض البيانات» لإظهار التقرير.</div><?php elseif(!$reportHasData): ?><div class="empty-state">لا يوجد شيء لعرضه ضمن الفترة والجهة المحددة، لذلك لا يمكن طباعة التقرير.</div><?php else: ?><div class="report-sheet report-portrait"><div class="panel-body"><?php report_header('تقرير التحصيل اليومي',$from,$to,$entityName!==''?'الجهة: '.$entityName:'كل الجهات'); ?><div class="table-wrap"><table class="table report-table collection-report-table"><thead><tr><th>رقم العميل</th><th>اسم العميل</th><th>عشاء</th><th>صبوح</th><th>غداء</th><th>الرصيد السابق</th><th>الإجمالي</th></tr></thead><tbody><?php
$sumDinner=0;$sumBreakfast=0;$sumLunch=0;$sumPrevious=0;$sumTotal=0;
foreach($rows as $r):
 $dinner=(float)$r['dinner']; $breakfast=(float)$r['breakfast']; $lunch=(float)$r['lunch'];
 // الرصيد السابق = المتبقي التراكمي قبل بداية الفترة.
 $previous=(float)$r['previous_balance'];
 // حسب المطلوب: الإجمالي يساوي الرصيد السابق + العشاء + الصبوح فقط.
 $total=$previous+$dinner+$breakfast;
 $sumDinner+=$dinner;$sumBreakfast+=$breakfast;$sumLunch+=$lunch;$sumPrevious+=$previous;$sumTotal+=$total;
?><tr><td><?=e($r['customer_no'])?></td><td><?=e($r['customer_name'])?></td><td><?=money($dinner)?></td><td><?=money($breakfast)?></td><td><?=money($lunch)?></td><td><?=money($previous)?></td><td><?=money($total)?></td></tr><?php endforeach; if(!$rows):?><tr><td colspan="7" class="empty-cell">لا توجد بيانات للتحصيل ضمن الفترة المحددة.</td></tr><?php endif;?></tbody><tfoot><tr><th colspan="2">الإجماليات</th><th><?=money($sumDinner)?></th><th><?=money($sumBreakfast)?></th><th><?=money($sumLunch)?></th><th><?=money($sumPrevious)?></th><th><?=money($sumTotal)?></th></tr></tfoot></table></div>
<div class="collection-notes">
  <div class="collection-notes-title">ملاحظات : العملاء الذين لم يصفو حسابهم السابق</div>
  <?php if($previousDebtors): ?>
    <ol class="collection-debtors-list">
      <?php foreach($previousDebtors as $d): ?>
        <li>
          <span class="debtor-name"><?=e($d['customer_name'])?></span>
          <span class="debtor-separator">—</span>
          <span class="debtor-balance-label">آخر سداد:</span>
          <strong class="debtor-last-payment"><?= $d['last_payment_date'] ? e($d['last_payment_date']) : 'لم يسبق له السداد' ?></strong>
          <span class="debtor-separator">—</span>
          <span class="debtor-balance-label">المبلغ المتبقي:</span>
          <strong class="debtor-balance-amount"><?=money((float)$d['balance'])?></strong>
        </li>
      <?php endforeach; ?>
    </ol>
  <?php else: ?>
    <div class="collection-notes-empty">لا يوجد عملاء تنطبق عليهم الشروط.</div>
  <?php endif; ?>
</div>
<?php report_footer(); ?></div></div><?php endif; ?>
<script>document.addEventListener('DOMContentLoaded',function(){var btns=document.querySelectorAll('button[onclick*="window.print"]');btns.forEach(function(b){b.addEventListener('click',function(ev){if(b.disabled){ev.preventDefault();alert('لا يوجد شيء لعرضه، لا يمكن طباعة تقرير فارغ.');}});});});</script>
<?php require __DIR__.'/../app/footer.php'; ?>
