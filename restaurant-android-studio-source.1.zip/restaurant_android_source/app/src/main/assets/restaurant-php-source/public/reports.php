<?php
// توافق مع الروابط القديمة: التقارير أصبحت صفحات مستقلة.
$type=$_GET['type']??'daily';
$map=['daily'=>'daily_collection.php','statement'=>'statement.php','accounts'=>'debts.php'];
header('Location: '.($map[$type]??'daily_collection.php')); exit;
