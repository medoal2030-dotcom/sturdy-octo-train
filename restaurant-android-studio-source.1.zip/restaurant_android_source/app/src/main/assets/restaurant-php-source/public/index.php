<?php
$title='الرئيسية'; require __DIR__.'/../app/header.php';
?>
<div class="page-title">القائمة الرئيسية</div>
<div class="dashboard-grid">
  <a class="dashboard-tile primary" href="customer.php"><span class="tile-icon">👥</span><strong>إدارة العملاء</strong><small>إضافة وتعديل بيانات العملاء والجهات</small></a>
  <a class="dashboard-tile success" href="order.php"><span class="tile-icon">🧾</span><strong>إضافة وإدارة الطلبات</strong><small>تسجيل الطلبات وتعديلها وحذفها</small></a>
  <a class="dashboard-tile warning" href="order_search.php"><span class="tile-icon">🔎</span><strong>بحث عن طلب</strong><small>برقم الطلب أو باسم العميل</small></a>
  <a class="dashboard-tile neutral" href="receipt.php"><span class="tile-icon">💰</span><strong>سند قبض</strong><small>تسجيل التحصيلات المالية</small></a>
  <?php if(($_SESSION['user']['role']??'')==='admin'):?><a class="dashboard-tile warning" href="approval_queue.php"><span class="tile-icon">✅</span><strong>اعتماد سندات القبض</strong><small>مراجعة سندات المحصلين قبل ترحيلها للحساب</small></a><?php endif;?>
  <a class="dashboard-tile neutral" href="discount.php"><span class="tile-icon">➖</span><strong>سند خصم</strong><small>تسجيل الخصومات على الحسابات</small></a>
  <a class="dashboard-tile report" href="daily_collection.php" target="_blank" rel="noopener"><span class="tile-icon">📊</span><strong>التحصيل اليومي</strong><small>صفحة مستقلة للتقرير والطباعة</small></a>
  <a class="dashboard-tile report" href="statement.php" target="_blank" rel="noopener"><span class="tile-icon">📄</span><strong>كشف حساب العميل</strong><small>كشف مستقل بين تاريخين أو كلي</small></a>
  <a class="dashboard-tile report" href="debts.php" target="_blank" rel="noopener"><span class="tile-icon">📋</span><strong>مديونيات العملاء</strong><small>ملخص كامل حسب الجهة</small></a>
</div>
<div class="home-welcome panel"><div class="panel-body"><h2>مرحبًا بك في نظام حسابات وديون المطعم</h2><p>اختر العملية المطلوبة من القائمة أعلاه. تم فصل صفحات الإدخال والبحث والتقارير لتجنب التكرار وتسهيل الاستخدام والطباعة.</p></div></div>
<?php require __DIR__.'/../app/footer.php'; ?>
