<?php
require_once __DIR__.'/../app/common.php';
if(!empty($_SESSION['user'])) redirect('index.php');
$yr=current_year($pdo);
$branch=setting('branch_no','1');
$err='';
$oldNo=trim($_POST['user_no']??''); $oldUsername=trim($_POST['username']??'');
if($_SERVER['REQUEST_METHOD']==='POST'){
  check_csrf();
  $u=$oldUsername; $p=$_POST['password']??''; $uid=(int)$oldNo;
  if($u==='' && $uid>0){
    $s=$pdo->prepare("SELECT * FROM users WHERE id=? AND active=1 LIMIT 1"); $s->execute([$uid]);
  } else {
    $s=$pdo->prepare("SELECT * FROM users WHERE username=? AND active=1 LIMIT 1"); $s->execute([$u]);
  }
  $row=$s->fetch();
  $identityOk=$row && ($uid<=0 || (int)$row['id']===$uid);
  if($identityOk && password_verify($p,$row['password_hash'])){
    $_SESSION['user']=['id'=>$row['id'],'username'=>$row['username'],'full_name'=>$row['full_name'],'role'=>$row['role']];
    redirect('index.php');
  }
  $err='بيانات الدخول غير صحيحة';
}
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>تسجيل الدخول</title><link rel="stylesheet" href="assets/style.css?v=20261008-9"></head>
<body class="login-page">
<div class="login-modal">
  <div class="login-head"><div class="login-icon">د</div><div><h1>تسجيل الدخول</h1><p>نظام حسابات وديون المطعم</p></div></div>
  <?php if($err): ?><div class="login-error"><?=e($err)?></div><?php endif; ?>
  <form method="post" autocomplete="off" id="loginForm"><input type="hidden" name="csrf" value="<?=e(csrf())?>">
    <div class="login-grid">
      <div class="login-field"><label>السنة المالية</label><input value="<?=e($yr['year_label'])?>" readonly></div>
      <div class="login-field"><label>رقم الفرع</label><input value="<?=e($branch)?>" readonly></div>
      <div class="login-field"><label>رقم المستخدم</label><input id="userNo" name="user_no" value="<?=e($oldNo)?>" inputmode="numeric" placeholder="رقم المستخدم"></div>
      <div class="login-field"><label>اسم المستخدم</label><input id="username" name="username" value="<?=e($oldUsername)?>" placeholder="اسم المستخدم"></div>
      <div class="login-field login-full"><label>كلمة المرور</label><input id="password" type="password" name="password" required placeholder="كلمة المرور"></div>
    </div>
    <label class="remember"><input type="checkbox" id="remember"> <span>حفظ البيانات للمرة القادمة</span></label>
    <div class="login-actions"><button type="submit" class="login-btn login-primary">دخول</button><button type="button" class="login-btn login-cancel" onclick="window.location.href='index.php'">إلغاء</button></div>
  </form>
</div>
<script>
(function(){
 const key='restaurantLoginData'; const no=document.getElementById('userNo'),u=document.getElementById('username'),remember=document.getElementById('remember'),form=document.getElementById('loginForm');
 try{const d=JSON.parse(localStorage.getItem(key)||'null');if(d){no.value=d.no||no.value;u.value=d.username||u.value;remember.checked=true;}}catch(e){}
 form.addEventListener('submit',function(){try{if(remember.checked)localStorage.setItem(key,JSON.stringify({no:no.value,username:u.value}));else localStorage.removeItem(key);}catch(e){}});
})();
</script></body></html>
