<?php
$title='كشف تحصيل المحصل'; require __DIR__.'/../app/header.php';
if(($_SESSION['user']['role']??'')!=='collector'){http_response_code(403);die('هذه الصفحة مخصصة للمحصل.');}
$yr=current_year($pdo); $viewData=(($_GET['view']??'')==='1'); $from=$_GET['from']??$yr['start_date']; $to=$_GET['to']??date('Y-m-d');
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$from))$from=$yr['start_date'];
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$to))$to=date('Y-m-d');
if($from>$to){$tmp=$from;$from=$to;$to=$tmp;}
$userId=(int)$_SESSION['user']['id'];
$sql="SELECT c.id,c.customer_no,c.name customer_name,
 SUM(CASE WHEN r.approval_status='approved' THEN r.amount ELSE 0 END) approved_total,
 SUM(CASE WHEN r.approval_status='pending' THEN r.amount ELSE 0 END) pending_total,
 SUM(CASE WHEN r.approval_status='rejected' THEN r.amount ELSE 0 END) rejected_total,
 SUM(CASE WHEN r.approval_status='approved' THEN 1 ELSE 0 END) approved_count,
 SUM(CASE WHEN r.approval_status='pending' THEN 1 ELSE 0 END) pending_count,
 SUM(CASE WHEN r.approval_status='rejected' THEN 1 ELSE 0 END) rejected_count,
 COUNT(r.id) receipt_count
 FROM receipts r JOIN customers c ON c.id=r.customer_id
 WHERE r.created_by=? AND r.receipt_date BETWEEN ? AND ?
 GROUP BY c.id,c.customer_no,c.name ORDER BY c.name,c.customer_no";
$customers=[]; if($viewData){$s=$pdo->prepare($sql);$s->execute([$userId,$from,$to]);$customers=$s->fetchAll();}
$approvedSum=0;$pendingSum=0;$rejectedSum=0;
foreach($customers as $c){$approvedSum+=(float)$c['approved_total'];$pendingSum+=(float)$c['pending_total'];$rejectedSum+=(float)$c['rejected_total'];}
$hasData=!empty($customers);
?>
<style>
.collector-report{width:100%;max-width:1180px;margin:0 auto;color:#243b46}
.collector-report .report-brand{display:none}
.collector-report .collector-summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:16px 0}
.collector-report .collector-stat{border:1px solid #d3e1e6;border-radius:10px;padding:15px 16px;background:#f7fbfc;min-width:0}
.collector-report .collector-stat span{display:block;color:#526875;font-size:14px;line-height:1.5;margin-bottom:8px}
.collector-report .collector-stat strong{display:block;font-size:24px;line-height:1.3;color:#087f78;overflow-wrap:anywhere}
.collector-report .collector-stat.pending strong{color:#956000}.collector-report .collector-stat.rejected strong{color:#a94332}
.collector-report .report-section-title{margin:22px 0 10px;color:#174b63;font-size:19px;font-weight:bold}
.collector-report .table-wrap{width:100%;overflow-x:auto}
.collector-report table{width:100%;border-collapse:collapse;table-layout:auto;background:#fff}
.collector-report th,.collector-report td{border:1px solid #cbd9df;padding:10px 9px;text-align:right;vertical-align:middle;line-height:1.45;white-space:normal;overflow-wrap:anywhere}
.collector-report th{background:#eaf4f7;color:#174b63;font-weight:bold}
.collector-report tbody tr:nth-child(even){background:#fbfdfe}
.collector-report tfoot th{background:#e0edf2;font-weight:bold}
.collector-report .status-pill{display:inline-block;padding:5px 9px;margin:2px 0;border-radius:20px;font-size:12px;white-space:nowrap}
.collector-report .status-approved{background:#d9f5e9;color:#16624c}.collector-report .status-pending{background:#fff0c8;color:#805400}.collector-report .status-rejected{background:#f9dddd;color:#8c2d2d}
.collector-report .report-brand-head{display:flex;align-items:center;justify-content:space-between;gap:20px;border-bottom:3px solid #174b63;padding:0 0 12px;margin-bottom:12px}
.collector-report .report-brand-logo{max-width:82px;max-height:72px;object-fit:contain}
.collector-report .report-brand-name{font-size:21px;color:#174b63;font-weight:bold;margin:0 0 5px}
.collector-report .report-brand-title{font-size:18px;font-weight:bold;margin:0}
.collector-report .report-brand-meta{text-align:left;font-size:12px;line-height:1.8;color:#526875}
.collector-report .panel{overflow:visible}
@media(max-width:700px){.collector-report .collector-summary{grid-template-columns:1fr}.collector-report th,.collector-report td{padding:8px 6px;font-size:13px}}
@media print{
 @page{size:A4 landscape;margin:12mm}
 html,body{background:#fff!important;color:#172f3a!important;width:100%!important;margin:0!important;padding:0!important;font-family:Tahoma,Arial,sans-serif!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
 .site,.layout,.content,main{display:block!important;width:100%!important;max-width:none!important;min-width:0!important;margin:0!important;padding:0!important;box-shadow:none!important;border:0!important;overflow:visible!important}
 .site>.topbar,.site>.nav,.year-banner,.no-print,.site>footer,.page-title,.sidebar,.footer{display:none!important}
 .collector-report{width:100%!important;max-width:none!important;margin:0!important;font-size:11pt!important}
 .collector-report .report-brand{display:block!important;margin:0 0 12px!important}
 .collector-report .report-brand-head{display:flex!important;align-items:center;justify-content:space-between;border-bottom:2px solid #174b63;padding-bottom:8px;margin-bottom:10px;break-inside:avoid}
 .collector-report .report-brand-logo{max-width:68px;max-height:58px}
 .collector-report .report-brand-name{font-size:17pt!important}.collector-report .report-brand-title{font-size:14pt!important}.collector-report .report-brand-meta{font-size:9pt!important}
 .collector-report .collector-summary{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:8px!important;margin:10px 0 14px!important;break-inside:avoid}
 .collector-report .collector-stat{padding:9px 12px!important;border-radius:5px!important;box-shadow:none!important}
 .collector-report .collector-stat span{font-size:9pt!important;margin-bottom:4px!important}
 .collector-report .collector-stat strong{font-size:16pt!important}
 .collector-report .report-section-title{font-size:12pt!important;margin:12px 0 6px!important;break-after:avoid}
 .collector-report .panel{border:0!important;box-shadow:none!important;margin:0 0 10px!important;break-inside:auto!important}
 .collector-report .panel-head{display:block!important;background:#eaf4f7!important;border:1px solid #cbd9df!important;padding:7px 9px!important;font-size:10pt!important;break-after:avoid}
 .collector-report .panel-body{padding:0!important}
 .collector-report .table-wrap{overflow:visible!important;width:100%!important}
 .collector-report table{width:100%!important;table-layout:fixed!important;border-collapse:collapse!important}
 .collector-report thead{display:table-header-group}
 .collector-report tfoot{display:table-row-group}
 .collector-report tr{break-inside:avoid;page-break-inside:avoid}
 .collector-report th,.collector-report td{font-size:9pt!important;padding:6px 5px!important;line-height:1.35!important;white-space:normal!important;overflow-wrap:anywhere!important;border:1px solid #aebfc7!important}
 .collector-report th{background:#eaf4f7!important;color:#174b63!important}
 .collector-report .status-pill{font-size:8pt!important;padding:3px 5px!important;margin:1px 0!important}
 .collector-report .no-print{display:none!important}
}
</style>
<?php if(!$viewData): ?><div class="empty-state">حدد الفترة ثم اضغط «عرض الكشف» لإظهار البيانات.</div><?php else: ?><div class="collector-report">
<div class="page-title">كشف التحصيل الخاص بالمحصل</div>
<div class="panel no-print"><div class="panel-head">خيارات الكشف</div><div class="panel-body"><form method="get"><input type="hidden" name="view" value="1"><div class="grid"><div class="col-4 form-row"><label>من تاريخ</label><input type="date" name="from" value="<?=e($from)?>" required></div><div class="col-4 form-row"><label>إلى تاريخ</label><input type="date" name="to" value="<?=e($to)?>" required></div></div><div class="actions"><button class="btn btn-primary" type="submit">عرض الكشف</button><button class="btn btn-secondary" type="button" onclick="window.print()" <?=$hasData?'':'disabled title="لا توجد بيانات للطباعة"'?>>طباعة الكشف</button><a class="btn btn-light" href="collector_report.php">إعادة ضبط</a></div></form></div></div>
<?php if(!$hasData):?><div class="empty-state">لا يوجد شيء لعرضه خلال الفترة المحددة، لذلك لا يمكن طباعة الكشف.</div><?php else:?>
<div class="report-brand"><div class="report-brand-head"><div style="display:flex;align-items:center;gap:14px;min-width:0"><?php if(!empty($restaurantLogo) && is_file(__DIR__.'/'.$restaurantLogo)): ?><img class="report-brand-logo" src="<?=e($restaurantLogo)?>" alt="شعار المنشأة"><?php endif; ?><div><div class="report-brand-name"><?=e(setting('restaurant_name_ar','نظام حسابات وديون المطعم'))?></div><div class="report-brand-title">كشف تحصيل المحصل</div></div></div><div class="report-brand-meta"><div>الفترة: <?=e($from)?> إلى <?=e($to)?></div><div>المحصل: <?=e($_SESSION['user']['full_name']??'المحصل')?></div><div>تاريخ الطباعة: <?=e(date('Y-m-d'))?></div></div></div></div>
<div class="collector-summary"><div class="collector-stat"><span>إجمالي السندات المعتمدة</span><strong><?=money($approvedSum)?></strong></div><div class="collector-stat pending"><span>بانتظار اعتماد المدير</span><strong><?=money($pendingSum)?></strong></div><div class="collector-stat rejected"><span>إجمالي السندات المرفوضة</span><strong><?=money($rejectedSum)?></strong></div></div>
<div class="panel"><div class="panel-head">كشف العملاء وحالة التحصيل</div><div class="panel-body"><div class="table-wrap"><table><thead><tr><th style="width:4%">م</th><th style="width:13%">رقم العميل</th><th style="width:22%">اسم العميل</th><th style="width:10%">عدد السندات</th><th style="width:23%">حالة السندات</th><th style="width:10%">المعتمد</th><th style="width:10%">بانتظار الاعتماد</th><th style="width:10%">المرفوض</th></tr></thead><tbody><?php foreach($customers as $i=>$c):?><tr><td><?=$i+1?></td><td><?=e($c['customer_no'])?></td><td><?=e($c['customer_name'])?></td><td><?=$c['receipt_count']?></td><td><?php if((int)$c['approved_count']>0):?><span class="status-pill status-approved">معتمد (<?= (int)$c['approved_count']?>)</span> <?php endif;?><?php if((int)$c['pending_count']>0):?><span class="status-pill status-pending">بانتظار الاعتماد (<?= (int)$c['pending_count']?>)</span> <?php endif;?><?php if((int)$c['rejected_count']>0):?><span class="status-pill status-rejected">مرفوض (<?= (int)$c['rejected_count']?>)</span><?php endif;?></td><td><?=money($c['approved_total'])?></td><td><?=money($c['pending_total'])?></td><td><?=money($c['rejected_total'])?></td></tr><?php endforeach;?></tbody><tfoot><tr><th colspan="5">الإجمالي</th><th><?=money($approvedSum)?></th><th><?=money($pendingSum)?></th><th><?=money($rejectedSum)?></th></tr></tfoot></table></div></div></div>
<?php endif;?></div><div class="report-print-footer"><span class="report-current-user"><?=e($_SESSION['user']['full_name']??'')?></span></div>
<?php endif; require __DIR__.'/../app/footer.php'; ?>
