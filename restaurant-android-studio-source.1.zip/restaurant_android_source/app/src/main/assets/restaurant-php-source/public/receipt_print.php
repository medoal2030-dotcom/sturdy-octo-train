<?php
require_once __DIR__.'/../app/common.php';
auth();
$id=(int)($_GET['id']??0);
$q=$pdo->prepare("SELECT r.*,c.customer_no,c.name AS customer_name,c.phone,c.address,e.name AS entity_name,u.full_name AS created_by_name FROM receipts r JOIN customers c ON c.id=r.customer_id LEFT JOIN entities e ON e.id=c.entity_id LEFT JOIN users u ON u.id=r.created_by WHERE r.id=? LIMIT 1");
$q->execute([$id]); $r=$q->fetch();
if(!$r){http_response_code(404);die('سند القبض غير موجود.');}
$role=$_SESSION['user']['role']??'';
if($r['approval_status']!=='approved' && $role!=='admin' && !((int)($r['created_by']??0)===(int)($_SESSION['user']['id']??0) && $role==='collector')){http_response_code(403);die('لا تملك صلاحية طباعة هذا السند.');}
$restaurantName=setting('restaurant_name_ar','نظام حسابات وديون المطعم');
$logo=setting('logo');
$amountWords=arabic_amount_words($r['amount']);
$logoPath='';
if($logo){
  $candidate=__DIR__.'/'.ltrim($logo,'/\\');
  if(is_file($candidate)) $logoPath=ltrim($logo,'/\\');
  elseif(is_file(__DIR__.'/../'.ltrim($logo,'/\\'))) $logoPath='../'.ltrim($logo,'/\\');
}
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>سند قبض <?=e($r['receipt_no'])?></title>
<style>
*{box-sizing:border-box}html,body{margin:0;padding:0}body{font-family:Tahoma,Arial,sans-serif;color:#202b33;background:#eef1f4;padding:18px}.toolbar{max-width:1120px;margin:0 auto 14px;display:flex;gap:8px;justify-content:flex-start}.btn{border:0;border-radius:5px;padding:10px 16px;text-decoration:none;font-size:14px;cursor:pointer}.primary{background:#087f82;color:#fff}.light{background:#e4edf3;color:#123d60}.receipt{width:100%;max-width:1120px;min-height:520px;margin:0 auto;background:#fff;border:1px solid #d6dce0;padding:24px 34px 30px;position:relative}.masthead{display:grid;grid-template-columns:1fr 1.15fr 1fr;align-items:center;gap:18px;padding-bottom:14px;border-bottom:2px solid #244b60}.brand{display:flex;align-items:center;gap:12px;min-width:0}.brand img{width:70px;height:70px;object-fit:contain}.brand-name{font-size:21px;font-weight:700;line-height:1.5;color:#183f56}.brand-meta{font-size:10px;color:#526875;line-height:1.7;overflow-wrap:anywhere}.voucher-title{text-align:center}.voucher-title h2{margin:0;font-size:30px;letter-spacing:.2px}.voucher-title .en{direction:ltr;display:inline-block;margin-top:4px;padding:4px 12px;border-bottom:2px solid #168bb5;font-size:13px;font-weight:bold;letter-spacing:.7px}.voucher-no{justify-self:end;text-align:center;min-width:145px}.voucher-no .label{display:block;background:#e4eef4;padding:6px 12px;border:1px solid #c5d4dc;border-bottom:0;font-size:12px;font-weight:bold}.voucher-no .value{display:block;border:1px solid #c5d4dc;padding:8px 10px;font-size:18px;font-weight:bold;color:#17628b;direction:ltr}.date-row{display:flex;justify-content:space-between;align-items:center;gap:18px;margin:13px 0 17px;font-size:13px}.date-box{display:flex;align-items:center;gap:10px}.date-box strong{border-bottom:1px dotted #6d8795;padding:7px 12px;min-width:135px;text-align:center;font-size:13px}.intro{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:12px}.line-field{display:grid;grid-template-columns:auto 1fr;gap:10px;align-items:end;min-height:34px;font-size:13px}.line-field .value{border-bottom:1px solid #8799a3;min-height:26px;padding:4px 8px;overflow-wrap:anywhere}.detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px 28px;margin-top:6px}.detail{display:grid;grid-template-columns:100px 1fr;gap:8px;align-items:end;font-size:12px}.detail .label{font-weight:bold;white-space:nowrap}.detail .value{border-bottom:1px dotted #9aaab2;min-height:27px;padding:4px 7px;overflow-wrap:anywhere}.amount-row{margin-top:17px;display:grid;grid-template-columns:1.35fr 1fr;gap:18px}.amount-box{border:1px solid #aabdc8;background:#f5f9fb;padding:11px 14px;display:flex;align-items:center;justify-content:space-between;gap:12px}.amount-box .caption{font-weight:bold;font-size:13px}.amount-box .amount{font-size:23px;font-weight:bold;color:#176f75;white-space:nowrap;direction:ltr}.amount-box .currency{font-size:15px;font-weight:bold}.words{margin-top:10px;padding:9px 12px;border-right:3px solid #168bb5;background:#f5f9fb;font-size:13px;line-height:1.8;min-height:38px}.notes{margin-top:8px;font-size:12px;line-height:1.7}.signatures{display:grid;grid-template-columns:1fr 1fr;gap:100px;margin:32px 18px 0;text-align:center}.sign-label{font-weight:bold;font-size:13px;margin-bottom:24px}.sign-line{border-bottom:1px solid #7e929d;height:12px}.thanks{text-align:center;color:#5a6f7a;font-size:10px;margin-top:15px}.footer-wave{margin-top:23px;height:6px;background:#168bb5;border-top:2px solid #244b60}
@page{size:A4 landscape;margin:8mm}@media print{body{background:#fff;padding:0;-webkit-print-color-adjust:exact;print-color-adjust:exact}.toolbar{display:none!important}.receipt{width:100%;max-width:none;min-height:0;height:auto;border:0;padding:5mm 7mm 4mm;break-inside:avoid}.masthead,.date-row,.intro,.detail-grid,.amount-row,.words,.signatures{break-inside:avoid}.footer-wave{margin-top:14px}}
@media(max-width:700px){body{padding:8px}.receipt{padding:16px}.masthead{grid-template-columns:1fr 1fr}.voucher-title{grid-column:1/-1;grid-row:2}.voucher-no{justify-self:end}.brand img{width:48px;height:48px}.brand-name{font-size:15px}.voucher-title h2{font-size:25px}.detail-grid,.intro{grid-template-columns:1fr;gap:8px}.detail{grid-template-columns:95px 1fr}.amount-row{grid-template-columns:1fr}.signatures{gap:28px;margin:28px 8px 0}.date-row{align-items:flex-start;flex-direction:column}}
</style></head><body>
<div class="toolbar"><button class="btn primary" onclick="window.print()">طباعة / حفظ PDF</button><a class="btn light" href="receipt.php">العودة إلى سندات القبض</a></div>
<main class="receipt">
<header class="masthead">
  <div class="brand"><?php if($logoPath): ?><img src="<?=e($logoPath)?>" alt="شعار المطعم"><?php endif; ?><div><div class="brand-name"><?=e($restaurantName)?></div><?php if(setting('address_ar')): ?><div class="brand-meta"><?=e(setting('address_ar'))?></div><?php endif; ?><?php if(setting('phones_ar')): ?><div class="brand-meta"><?=e(setting('phones_ar'))?></div><?php endif; ?></div></div>
  <div class="voucher-title"><h2>سند قبض</h2><div class="en">RECEIPT VOUCHER</div></div>
  <div class="voucher-no"><span class="label">رقم السند</span><span class="value"><?=e($r['receipt_no'])?></span></div>
</header>
<div class="date-row"><div class="date-box"><span>التاريخ</span><strong><?=e($r['receipt_date'])?></strong></div><div class="date-box"><span>استلمنا من السيد / العميل</span><strong><?=e($r['customer_name'])?></strong></div></div>
<div class="intro">
  <div class="line-field"><strong>اسم العميل:</strong><div class="value"><?=e($r['customer_name'])?></div></div>
  <div class="line-field"><strong>المبلغ المستلم:</strong><div class="value" dir="ltr"><?=money($r['amount'])?> ريال يمني</div></div>
</div>
<section class="detail-grid">
  <div class="detail"><div class="label">رقم العميل:</div><div class="value" dir="ltr"><?=e($r['customer_no'])?></div></div>
  <div class="detail"><div class="label">الجهة:</div><div class="value"><?=e($r['entity_name']??'—')?></div></div>
  <div class="detail"><div class="label">رقم الجوال:</div><div class="value" dir="ltr"><?=e($r['phone']?:'—')?></div></div>
  <div class="detail"><div class="label">المحصل:</div><div class="value"><?=e($r['collector']?:$r['created_by_name']?:'—')?></div></div>
</section>
<div class="amount-row"><div class="amount-box"><span class="caption">المبلغ كتابةً</span><strong class="currency"><?=e($amountWords)?> فقط لا غير</strong></div><div class="amount-box"><span class="caption">العملة</span><strong class="currency">ريال يمني</strong></div></div>
<div class="words"><strong>وذلك مقابل:</strong> سداد مبلغ من مديونية العميل.</div>
<?php if(trim((string)$r['notes'])!==''): ?><div class="notes"><strong>ملاحظات:</strong> <?=e($r['notes'])?></div><?php endif; ?>
<div class="signatures"><div><div class="sign-label">المحاسب / المحصّل</div><div class="sign-line"></div></div><div><div class="sign-label">المستلم / العميل</div><div class="sign-line"></div></div></div>
<div class="thanks">نشكركم على تعاملكم معنا</div><div class="footer-wave"></div>
</main>
<?php if(isset($_GET['autoprint'])): ?><script>window.addEventListener('load',()=>setTimeout(()=>window.print(),300));</script><?php endif; ?></body></html>
