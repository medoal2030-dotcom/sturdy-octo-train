<?php
require __DIR__.'/../app/common.php'; auth();
$viewData=(($_GET['view']??'')==='1');
$status = $_GET['status'] ?? 'all';
if (!in_array($status, ['all','active','stopped'], true)) $status='all';
$entityId = (int)($_GET['entity_id'] ?? 0);
$entities = $pdo->query("SELECT id,name FROM entities ORDER BY name")->fetchAll();
$where=[]; $params=[];
if($status==='active') $where[]='c.active=1';
elseif($status==='stopped') $where[]='c.active=0';
if($entityId>0){$where[]='c.entity_id=?';$params[]=$entityId;}
$sql="SELECT c.customer_no,c.name,c.phone,e.name entity_name,c.address,c.opening_balance,c.active FROM customers c JOIN entities e ON e.id=c.entity_id";
if($where)$sql.=' WHERE '.implode(' AND ',$where);
$sql.=" ORDER BY e.name,c.name";
$rows=[]; if($viewData){$stmt=$pdo->prepare($sql);$stmt->execute($params);$rows=$stmt->fetchAll();}
$restaurantName=setting('restaurant_name_ar','نظام حسابات وديون المطعم');
$entityLabel='كل الجهات';foreach($entities as $en){if((int)$en['id']===$entityId){$entityLabel=$en['name'];break;}}
$title=$status==='active'?'تقرير العملاء المفعّلين':($status==='stopped'?'تقرير العملاء الموقوفين':'تقرير جميع العملاء');
if($entityId>0)$title.=' — '.$entityLabel;
$showStatus=$status!=='active';
?>
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($title)?></title><link rel="stylesheet" href="assets/style.css?v=20261014-customers-report-3"><style>
*{box-sizing:border-box}
body{background:#fff;margin:0;color:#20313b;font-family:Tahoma,Arial,sans-serif}
.report-page{width:min(100%,1200px);margin:16px auto;padding:16px; color:#20313b}
.report-top{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;border-bottom:2px solid #244b67;padding:0 0 12px;margin-bottom:14px}
.report-top h1{font-size:22px;line-height:1.4;margin:0 0 5px;overflow-wrap:anywhere}
.report-top p{font-size:14px;line-height:1.5;margin:0;color:#667}
.report-date{white-space:nowrap;font-size:13px;padding-top:4px}
.report-title{text-align:center;margin:16px 0 8px;font-size:19px;line-height:1.4}
.report-count{margin:0 0 10px;color:#556;font-size:13px}
.report-table-wrap{width:100%;overflow-x:auto;border-radius:5px}
.report-table{width:100%;min-width:760px;border-collapse:collapse;table-layout:fixed;font-size:12px}
.report-table th{background:#eaf2f6;color:#183f5a;font-weight:700}
.report-table th,.report-table td{border:1px solid #bdcbd3;padding:8px 6px;text-align:right;vertical-align:middle;line-height:1.45;overflow-wrap:anywhere;word-break:normal}
.report-table tbody tr:nth-child(even) td{background:#fafcfd}
.report-table td.num,.report-table th.num{text-align:center;white-space:nowrap}
.report-table td.phone,.report-table td.customer-no{direction:ltr;text-align:center;overflow-wrap:anywhere}
.state-active{color:#176b50;font-weight:bold}.state-stopped{color:#9b3b25;font-weight:bold}
.report-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:0 0 14px}
.report-actions button,.report-actions a{padding:10px 14px;border:0;border-radius:6px;background:#287d78;color:#fff;font-size:14px;text-decoration:none;cursor:pointer}
.report-actions select{padding:10px;border:1px solid #ccd;border-radius:6px;font:inherit;max-width:100%}
.report-actions .secondary{background:#244b67}
.report-actions form{margin:0}
@media(max-width:600px){.report-page{padding:10px;margin:0}.report-top h1{font-size:19px}.report-top{gap:8px}.report-date{font-size:11px;white-space:normal;text-align:left}.report-title{font-size:17px}.report-actions button,.report-actions a{font-size:13px;padding:9px 11px}.report-actions form{width:100%}.report-actions select{flex:1;min-width:0}.report-table{font-size:11px}}
@media print{
 @page{size:A4 landscape;margin:8mm}
 html,body{width:100%!important;margin:0!important;padding:0!important;background:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}
 .report-page{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}
 .report-actions,.no-print{display:none!important}
 .report-top{margin:0 0 8mm;padding-bottom:4mm;align-items:flex-start}
 .report-top h1{font-size:16pt}.report-top p{font-size:10pt}.report-date{font-size:9pt}
 .report-title{font-size:13pt;margin:4mm 0 2mm}
 .report-count{font-size:9pt;margin:0 0 3mm}
 .report-table-wrap{overflow:visible!important;width:100%!important}
 .report-table{width:100%!important;min-width:0!important;table-layout:fixed!important;font-size:8.5pt!important;border-collapse:collapse!important}
 .report-table th,.report-table td{padding:2.2mm 1.5mm!important;line-height:1.25!important;overflow-wrap:anywhere;word-break:normal}
 .report-table thead{display:table-header-group}
 .report-table tr{break-inside:avoid;page-break-inside:avoid}
 .report-table th:nth-child(1){width:4%}.report-table th:nth-child(2){width:12%}.report-table th:nth-child(3){width:17%}.report-table th:nth-child(4){width:13%}.report-table th:nth-child(5){width:13%}.report-table th:nth-child(6){width:22%}.report-table th:nth-child(7){width:10%}.report-table th:nth-child(8){width:9%}
}
</style></head><body><main class="report-page">
<div class="report-actions no-print"><a class="secondary" href="customer.php">العودة إلى شاشة العملاء</a><a class="secondary" href="index.php">الرئيسية</a><button onclick="window.print()" <?=(!$viewData || empty($rows))?'disabled title="لا توجد بيانات للطباعة"':''?>>طباعة / حفظ PDF</button><a class="secondary" href="customers_report.php?status=active<?= $entityId?'&entity_id='.$entityId:'' ?>">العملاء المفعّلون</a><a class="secondary" href="customers_report.php?status=stopped<?= $entityId?'&entity_id='.$entityId:'' ?>">العملاء الموقوفون</a><a class="secondary" href="customers_report.php?status=all<?= $entityId?'&entity_id='.$entityId:'' ?>">جميع العملاء</a><form method="get" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><input type="hidden" name="view" value="1"><input type="hidden" name="status" value="<?=e($status)?>"><label for="entity">تقرير حسب الجهة:</label><select id="entity" name="entity_id"><option value="0">كل الجهات</option><?php foreach($entities as $en):?><option value="<?=$en['id']?>" <?=((int)$en['id']===$entityId?'selected':'')?>><?=e($en['name'])?></option><?php endforeach;?></select><button type="submit">عرض التقرير</button></form></div>
<header class="report-top"><div><h1><?=e($restaurantName)?></h1><p><?=e($title)?></p></div><div class="report-date">تاريخ التقرير: <?=e(date('Y-m-d'))?></div></header>
<h2 class="report-title"><?=e($title)?></h2><div class="report-count"><?php if($viewData): ?>عدد العملاء: <?=count($rows)?><?php else: ?>اضغط «عرض التقرير» لإظهار البيانات.<?php endif; ?></div>
<?php if(!$viewData): ?><div class="empty-state">اختر خيارات التقرير ثم اضغط «عرض التقرير».</div><?php elseif(empty($rows)): ?><div class="empty-state">لا يوجد شيء لعرضه وفق الخيارات المحددة، لذلك لا يمكن طباعة التقرير.</div><?php else: ?><div class="report-table-wrap"><table class="report-table"><thead><tr><th class="num">م</th><th>رقم العميل</th><th>اسم العميل</th><th>رقم الجوال</th><th>الجهة</th><th>العنوان التفصيلي</th><th class="num">الرصيد الافتتاحي</th><?php if($showStatus):?><th class="num">الحالة</th><?php endif;?></tr></thead><tbody><?php foreach($rows as $i=>$r):?><tr><td class="num"><?=$i+1?></td><td class="customer-no"><?=e($r['customer_no'])?></td><td><?=e($r['name'])?></td><td class="phone"><?=e($r['phone'])?></td><td><?=e($r['entity_name'])?></td><td><?=e($r['address'])?></td><td class="num"><?=number_format((float)$r['opening_balance'],2)?></td><?php if($showStatus):?><td class="num"><span class="<?=((int)$r['active']?'state-active':'state-stopped')?>"><?=((int)$r['active']?'مفعّل':'موقوف')?></span></td><?php endif;?></tr><?php endforeach;?></tbody></table></div><?php endif; ?><div class="report-print-footer"><span class="report-current-user"><?=e($_SESSION['user']['full_name']??'')?></span></div></main><script>document.addEventListener('DOMContentLoaded',function(){var btns=document.querySelectorAll('button[onclick*="window.print"]');btns.forEach(function(b){b.addEventListener('click',function(ev){if(b.disabled){ev.preventDefault();alert('لا يوجد شيء لعرضه، لا يمكن طباعة تقرير فارغ.');}});});});</script><script>document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('input[type=\"date\"]').forEach(function(o){if(o.dataset.manualDateReady)return;o.dataset.manualDateReady='1';var w=document.createElement('div');w.style.cssText='display:flex;gap:5px;position:relative';var t=document.createElement('input');t.type='text';t.name=o.name;t.value=o.value;t.placeholder='YYYY-MM-DD';t.pattern='\\d{4}-\\d{2}-\\d{2}';t.required=o.required;t.style.flex='1';var b=document.createElement('button');b.type='button';b.textContent='📅';b.className='secondary';var c=document.createElement('input');c.type='date';c.value=o.value;c.style.cssText='position:absolute;left:0;opacity:0;width:42px;height:100%';w.append(t,b,c);o.replaceWith(w);t.addEventListener('input',function(){if(/^\\d{4}-\\d{2}-\\d{2}$/.test(t.value))c.value=t.value;});c.addEventListener('change',function(){t.value=c.value;});b.addEventListener('click',function(){try{c.showPicker?c.showPicker():c.click()}catch(e){c.click()}});});});</script></body></html>
