CREATE DATABASE IF NOT EXISTS restaurant_debts CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE restaurant_debts;

CREATE TABLE IF NOT EXISTS fiscal_years (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  year_label VARCHAR(20) NOT NULL UNIQUE,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  closed_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(80) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  role ENUM('admin','accountant','cashier','collector','viewer') NOT NULL DEFAULT 'cashier',
  active TINYINT(1) NOT NULL DEFAULT 1,
  permissions TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS entities (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS meal_types (
  id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(30) NOT NULL UNIQUE,
  sort_order TINYINT UNSIGNED NOT NULL DEFAULT 1,
  active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cashiers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS customers (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  customer_no VARCHAR(30) NOT NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  phone VARCHAR(40) NULL,
  address VARCHAR(255) NULL,
  entity_id INT UNSIGNED NOT NULL,
  opening_balance DECIMAL(12,2) NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_customers_entity FOREIGN KEY (entity_id) REFERENCES entities(id),
  INDEX idx_customers_entity(entity_id), INDEX idx_customers_name(name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS customer_year_balances (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fiscal_year_id INT UNSIGNED NOT NULL,
  customer_id INT UNSIGNED NOT NULL,
  opening_balance DECIMAL(12,2) NOT NULL DEFAULT 0,
  UNIQUE KEY uq_customer_year (fiscal_year_id, customer_id),
  CONSTRAINT fk_cyb_year FOREIGN KEY (fiscal_year_id) REFERENCES fiscal_years(id) ON DELETE CASCADE,
  CONSTRAINT fk_cyb_customer FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_no VARCHAR(30) NOT NULL UNIQUE,
  customer_id INT UNSIGNED NOT NULL,
  meal_type_id TINYINT UNSIGNED NOT NULL,
  cashier_id INT UNSIGNED NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  received_by VARCHAR(150) NULL,
  order_date DATE NOT NULL,
  notes VARCHAR(500) NULL,
  fiscal_year_id INT UNSIGNED NOT NULL,
  created_by INT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(id),
  CONSTRAINT fk_orders_meal FOREIGN KEY (meal_type_id) REFERENCES meal_types(id),
  CONSTRAINT fk_orders_cashier FOREIGN KEY (cashier_id) REFERENCES cashiers(id),
  CONSTRAINT fk_orders_year FOREIGN KEY (fiscal_year_id) REFERENCES fiscal_years(id),
  CONSTRAINT fk_orders_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_orders_date(order_date), INDEX idx_orders_customer(customer_id), INDEX idx_orders_year(fiscal_year_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS receipts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  receipt_no VARCHAR(30) NOT NULL UNIQUE,
  customer_id INT UNSIGNED NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  collector VARCHAR(150) NULL,
  receipt_date DATE NOT NULL,
  fiscal_year_id INT UNSIGNED NOT NULL,
  notes VARCHAR(500) NULL,
  approval_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved',
  approved_by INT UNSIGNED NULL,
  approved_at DATETIME NULL,
  created_by INT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_receipts_customer FOREIGN KEY (customer_id) REFERENCES customers(id),
  CONSTRAINT fk_receipts_year FOREIGN KEY (fiscal_year_id) REFERENCES fiscal_years(id),
  CONSTRAINT fk_receipts_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_receipts_approved_by FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_receipts_date(receipt_date), INDEX idx_receipts_customer(customer_id), INDEX idx_receipts_year(fiscal_year_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS discounts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  discount_no VARCHAR(30) NOT NULL UNIQUE,
  customer_id INT UNSIGNED NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  discounted_by VARCHAR(150) NOT NULL,
  discount_date DATE NOT NULL,
  fiscal_year_id INT UNSIGNED NOT NULL,
  notes VARCHAR(500) NULL,
  created_by INT UNSIGNED NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_discounts_customer FOREIGN KEY (customer_id) REFERENCES customers(id),
  CONSTRAINT fk_discounts_year FOREIGN KEY (fiscal_year_id) REFERENCES fiscal_years(id),
  CONSTRAINT fk_discounts_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_discounts_date(discount_date), INDEX idx_discounts_customer(customer_id), INDEX idx_discounts_year(fiscal_year_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS system_settings (
  id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  restaurant_name_ar VARCHAR(180) NOT NULL DEFAULT 'نظام حسابات وديون المطعم',
  restaurant_name_en VARCHAR(180) NULL,
  address_ar VARCHAR(255) NULL,
  address_en VARCHAR(255) NULL,
  phones_ar VARCHAR(255) NULL,
  phones_en VARCHAR(255) NULL,
  logo VARCHAR(255) NULL,
  branch_no VARCHAR(50) NOT NULL DEFAULT '1',
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO system_settings(id,restaurant_name_ar) VALUES(1,'نظام حسابات وديون المطعم');

INSERT IGNORE INTO entities(name) VALUES ('القيادة'),('السوق'),('المقوات'),('الجمارك');
INSERT IGNORE INTO meal_types(name,sort_order) VALUES ('صبوح',1),('غداء',2),('عشاء',3);
INSERT IGNORE INTO cashiers(name) VALUES ('الكاشير الرئيسي');
INSERT IGNORE INTO fiscal_years(year_label,start_date,end_date,status) VALUES (YEAR(CURDATE()), MAKEDATE(YEAR(CURDATE()),1), MAKEDATE(YEAR(CURDATE())+1,1)-INTERVAL 1 DAY,'open');

-- Initial admin: admin / admin123 (change after first login)
INSERT INTO users(username,password_hash,full_name,role) SELECT 'admin', '$2y$12$f9q61r0mTE8SRXVerhrSq.9WUDlVXl8FtX8/VA6/vxTc0Rr.HVQ/y', 'مدير النظام', 'admin'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='admin');

INSERT IGNORE INTO customer_year_balances(fiscal_year_id,customer_id,opening_balance)
SELECT f.id,c.id,c.opening_balance FROM fiscal_years f CROSS JOIN customers c WHERE f.status='open';


CREATE TABLE IF NOT EXISTS user_notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  receipt_id BIGINT UNSIGNED NULL,
  message VARCHAR(255) NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_notifications(user_id,is_read,id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
