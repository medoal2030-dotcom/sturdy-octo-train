#!/usr/bin/env bash
set -euo pipefail

if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Install Gradle 8.9 and Android SDK platform 35 first." >&2
  exit 2
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Set ANDROID_HOME or ANDROID_SDK_ROOT to an installed Android SDK." >&2
  exit 2
fi
gradle --no-daemon clean assembleDebug
printf '\nAPK path: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
printf 'NOTICE: this current foundation APK is a setup shell; it does not yet run the PHP/MariaDB accounting backend.\n'
